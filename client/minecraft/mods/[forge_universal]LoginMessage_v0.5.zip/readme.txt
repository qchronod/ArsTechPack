LoginMessage mod for MinecraftForge

Introduction to
1. Backup the minecraft.jar/minecraft_server.jar file.
2. Introduced the MinecraftForge into minecraft.jar/minecraft_server.jar
3. Put LoginMessage zip file into mods folder.
4. Start the minecraft/minecraft_server. (LoginMessage.txt is generated)
5. Please edit LoginMessage.txt suitably.
### Attention META-INF is not deleted.(minecraft_server.jar) ###


Usable special character string.
%host - Shows the host player name. (Shows the "Hoge" in a multi-server)
%nm - Shows the player's name.
%size - The number of how many players are in the server.
%max - The limit, or max amount of players allowed in your server at once. This is defined in server.properties.
%ol - This shows the online list.
%% - Escape the %
&& - Escape the &
%k: Random Style
%l: Bold Style
%m: Strikethrough Style
%n: Underline Style
%o: Italic Style
%r: Style/Color code reset


Color code.
&0 - Black
&1 - Dark blue
&2 - Dark green
&3 - Teal
&4 - Red
&5 - Purple
&6 - Gold
&7 - Light gray
&8 - Dark gray
&9 - Blue
&a - Light green
&b - Light blue
&c - Light red
&d - Pink
&e - Yellow
&f - White