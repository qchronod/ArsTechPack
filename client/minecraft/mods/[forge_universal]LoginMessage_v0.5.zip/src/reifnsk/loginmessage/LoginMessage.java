package reifnsk.loginmessage;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.packet.Packet3Chat;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.ServerConfigurationManager;
import net.minecraft.util.ChatMessageComponent;

public class LoginMessage
{
    private static boolean init;

    private static Pattern loginMessagePattern;
    private static File loginMessageFile = new File("LoginMessage.txt");
    private static HashMap<String, String> map = new HashMap<String, String>();


    public static synchronized void init()
    {
        if (init) return;

        // Pattern設定
        loginMessagePattern = Pattern.compile("%nm|%size|%host|%max|%ol|%%|&&|&([0123456789abcdefklmnor])");

        // LoginMessage.txtが存在しない場合デフォルトファイルを出力する
        if (!loginMessageFile.exists())
        {
            PrintWriter out = null;
            try
            {
                out = new PrintWriter(loginMessageFile);
                out.println("&eWelcome to &c%host's &eserver, &b%nm&e!!&0&0&1&2&3&4&5&6&7&e&f");
                out.println("Server capacity: %size/%max");
                out.println("Currently online: %ol");
                out.flush();
            } catch (IOException e)
            {
            } finally
            {
                if (out != null) out.close();
            }
        }

        map.put("%%", "%");
        map.put("&&", "&");
        for (char c : "0123456789abcdefklmnor".toCharArray())
            map.put(String.format("&%s", c), String.format("\247%s", c));

        init = true;
    }

    public static synchronized void sendMessage(EntityPlayerMP entityPlayer)
    {
        if (!init) return;

        ServerConfigurationManager scm = MinecraftServer.getServer().getConfigurationManager();
        String username = entityPlayer.username;
        String serverOwner = MinecraftServer.getServer().getServerOwner();
        map.put("%host", serverOwner == null || serverOwner.isEmpty() ? "Hoge" : serverOwner);
        map.put("%nm", username);
        map.put("%size", Integer.toString(scm.playerEntityList.size()));
        map.put("%max", Integer.toString(scm.getMaxPlayers()));

        String online = null;

        Scanner in = null;
        try
        {
            for (in = new Scanner(loginMessageFile); in.hasNextLine();)
            {
                String mes = in.nextLine();
                StringBuffer sb = new StringBuffer();
                Matcher mat = loginMessagePattern.matcher(mes);
                while (mat.find())
                {
                    String replacement = map.get(mat.group());

                    if (replacement == null)
                    {
                        if ("%ol".equals(mat.group()))
                        {
                            if (online == null)
                            {
                                StringBuilder temp = new StringBuilder();
                                for (EntityPlayer p : (List<EntityPlayer>) scm.playerEntityList)
                                {
                                    temp.append(p.username).append(", ");
                                }
                                if (temp.length() != 0)
                                {
                                    temp.setLength(temp.length() - 2);
                                }
                                online = temp.toString();
                            }
                            replacement = online;
                        }
                    }

                    mat.appendReplacement(sb, replacement != null ? replacement : "");
                }
                mat.appendTail(sb);
                entityPlayer.playerNetServerHandler.sendPacketToPlayer(new Packet3Chat(ChatMessageComponent.func_111082_b(sb.toString()), true));
            }
        } catch (Exception e)
        {
        } finally
        {
            try
            {
                if (in != null) in.close();
            } catch (Exception e)
            {
            }
        }
    }

    private LoginMessage()
    {
    }
}
